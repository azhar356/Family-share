package com.example.galleryshare

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Telephony
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

class MainActivity : AppCompatActivity() {
    private val client = OkHttpClient()
    private val prefs by lazy { getSharedPreferences("gallery_share", MODE_PRIVATE) }
    private lateinit var server: EditText
    private lateinit var name: EditText
    private lateinit var status: TextView
    private val pick = 1001
    private val smsReq = 2001

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        server = findViewById(R.id.server)
        name = findViewById(R.id.deviceName)
        status = findViewById(R.id.status)
        server.setText(prefs.getString("server", ""))
        name.setText(prefs.getString("name", "My phone"))
        status.text = if (prefs.getString("deviceToken", null) != null) "Device registered" else "Not registered"

        findViewById<Button>(R.id.register).setOnClickListener { registerDevice() }
        findViewById<Button>(R.id.select).setOnClickListener {
            if (checkRegistered()) pickPhotos()
        }
        findViewById<Button>(R.id.sms).setOnClickListener {
            if (!checkRegistered()) return@setOnClickListener
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
                status.text = "Android SMS permission required. Nothing is shared yet."
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_SMS), smsReq)
            } else {
                syncSms()
            }
        }
    }

    private fun base() = server.text.toString().trim().trimEnd('/')

    private fun checkRegistered(): Boolean {
        if (base().isBlank() || prefs.getString("deviceToken", null) == null) {
            status.text = "Enter server URL and register this phone first"
            return false
        }
        return true
    }

    private fun registerDevice() {
        val b = base()
        if (b.isBlank()) { status.text = "Enter your server URL"; return }
        val deviceName = name.text.toString().trim().ifBlank { "Android phone" }
        val body = JSONObject().put("name", deviceName).toString().toRequestBody("application/json".toMediaType())
        val req = Request.Builder().url("$b/api/device/register").post(body).build()
        status.text = "Registering this phone..."
        client.newCall(req).enqueue(callback { r ->
            val s = r.body?.string().orEmpty()
            if (!r.isSuccessful) { status.text = "Registration failed: $s"; return@callback }
            val x = JSONObject(s)
            prefs.edit().putString("server", b).putString("name", deviceName).putString("deviceId", x.getString("deviceId")).putString("deviceToken", x.getString("deviceToken")).apply()
            runOnUiThread { status.text = "Registered. Choose what you want to share below." }
        })
    }

    private fun pickPhotos() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "image/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(i, pick)
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r != pick || c != Activity.RESULT_OK || d == null) return
        val list = mutableListOf<Uri>()
        d.clipData?.let { x -> for (i in 0 until x.itemCount) list.add(x.getItemAt(i).uri) }
            ?: d.data?.let { list.add(it) }
        val total = list.size
        list.forEachIndexed { idx, uri -> upload(uri, idx + 1, total) }
    }

    private fun upload(uri: Uri, n: Int, total: Int) {
        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return
        val body = bytes.toRequestBody("image/*".toMediaType())
        val req = Request.Builder()
            .url("${base()}/api/upload")
            .header("x-device-token", prefs.getString("deviceToken", "")!!)
            .post(MultipartBody.Builder().setType(MultipartBody.FORM).addFormDataPart("photo", "photo-$n.jpg", body).build())
            .build()
        runOnUiThread { status.text = "Uploading $n/$total..." }
        client.newCall(req).enqueue(callback { r -> runOnUiThread { status.text = if (r.isSuccessful && n == total) "Selected photos uploaded" else if (!r.isSuccessful) "Photo upload failed" else "Uploaded $n/$total" } })
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == smsReq) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
                syncSms()
            } else {
                status.text = "SMS permission was denied; no SMS was shared."
            }
        }
    }

    private fun syncSms() {
        status.text = "Syncing SMS you approved..."
        Thread {
            val arr = JSONArray()
            contentResolver.query(Telephony.Sms.CONTENT_URI, arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE), null, null, Telephony.Sms.DATE + " DESC")?.use { c ->
                var n = 0
                while (c.moveToNext() && n < 500) {
                    arr.put(JSONObject().put("address", c.getString(0)).put("body", c.getString(1)).put("date", c.getLong(2)))
                    n++
                }
            }
            val body = JSONObject().put("messages", arr).toString().toRequestBody("application/json".toMediaType())
            val req = Request.Builder().url("${base()}/api/sms/sync").header("x-device-token", prefs.getString("deviceToken", "")!!).post(body).build()
            client.newCall(req).enqueue(callback { r -> runOnUiThread { status.text = if (r.isSuccessful) "SMS synced by your request" else "SMS sync failed" } })
        }.start()
    }

    private fun callback(fn: (Response) -> Unit) = object : Callback {
        override fun onFailure(c: Call, e: IOException) { runOnUiThread { status.text = "Network error: ${e.message}" } }
        override fun onResponse(c: Call, r: Response) { r.use { fn(it) } }
    }
}
