# Family Share — consent-based Android + Admin

This project intentionally uses **no pairing code**. A phone registers itself with the server, but registration does not grant access to its private data.

## Flow
1. Start the Node.js server with a strong `ADMIN_TOKEN`.
2. Install/build the Android app.
3. On the phone owner’s device, enter the HTTPS server URL and tap **Register this phone**.
4. The owner chooses photos with Android’s file picker. Only those selected photos are uploaded.
5. For SMS, the owner taps **Allow & sync SMS now**, grants Android's SMS permission, and then the app sends the current SMS list. There is no hidden/background SMS forwarding.
6. Open `/admin`, enter the admin token, and refresh devices/photos/SMS.

## Server
```bash
cd server
npm install
ADMIN_TOKEN='use-a-long-random-secret' npm start
```

Use HTTPS in any real deployment. Do not expose port 8080 directly to the public internet without TLS/reverse proxy and authentication.

## Android build
Open `android/` in Android Studio and build a debug APK. The APK will normally be under `android/app/build/outputs/apk/debug/`.

## Android SMS note
`READ_SMS` is a restricted/sensitive Android permission and Google Play has additional eligibility/policy requirements. For personal sideloading, the Android OS permission dialog still controls access. Do not use this project to hide monitoring from the phone owner.
