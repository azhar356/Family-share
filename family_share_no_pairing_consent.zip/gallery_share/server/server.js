const express=require('express');
const multer=require('multer');
const cors=require('cors');
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const app=express();
const PORT=process.env.PORT||8080;
const ADMIN_TOKEN=process.env.ADMIN_TOKEN||'CHANGE_ME_NOW';
const uploadDir=path.join(__dirname,'uploads');
const devicesFile=path.join(__dirname,'devices.json');
const smsFile=path.join(__dirname,'sms.json');
fs.mkdirSync(uploadDir,{recursive:true});
for(const f of [devicesFile,smsFile]) if(!fs.existsSync(f)) fs.writeFileSync(f,'{}');
app.use(cors()); app.use(express.json({limit:'2mb'})); app.use('/uploads',express.static(uploadDir)); app.use('/admin',express.static(path.join(__dirname,'public')));
const readJson=f=>JSON.parse(fs.readFileSync(f,'utf8')||'{}'); const writeJson=(f,x)=>fs.writeFileSync(f,JSON.stringify(x,null,2));
const storage=multer.diskStorage({destination:uploadDir,filename:(req,file,cb)=>cb(null,Date.now()+'-'+crypto.randomBytes(5).toString('hex')+path.extname(file.originalname).toLowerCase())});
const upload=multer({storage,limits:{fileSize:20*1024*1024},fileFilter:(req,file,cb)=>cb(null,/^image\/(jpeg|png|webp|heic|heif)$/.test(file.mimetype))});
function admin(req,res,next){if(req.get('x-admin-token')!==ADMIN_TOKEN)return res.status(401).json({error:'Unauthorized'});next()}
function device(req,res,next){const token=req.get('x-device-token');const devices=readJson(devicesFile);const d=Object.values(devices).find(x=>x.token===token);if(!d)return res.status(401).json({error:'Invalid device token'});req.device=d;next()}
app.post('/api/device/register',(req,res)=>{const devices=readJson(devicesFile);const id=crypto.randomUUID();const token=crypto.randomBytes(32).toString('hex');devices[id]={id,token,name:String(req.body.name||'Android phone').slice(0,80),registeredAt:new Date().toISOString()};writeJson(devicesFile,devices);res.json({deviceId:id,deviceToken:token})});
app.get('/api/devices',admin,(req,res)=>res.json(Object.values(readJson(devicesFile)).filter(x=>x.id)));
app.post('/api/upload',device,upload.single('photo'),(req,res)=>{if(!req.file)return res.status(400).json({error:'No photo'});res.json({ok:true,file:req.file.filename,deviceId:req.device.id})});
app.post('/api/sms/sync',device,(req,res)=>{const rows=Array.isArray(req.body.messages)?req.body.messages:[];if(rows.length>500)return res.status(400).json({error:'Too many messages'});const all=readJson(smsFile);all[req.device.id]={deviceId:req.device.id,deviceName:req.device.name,updatedAt:new Date().toISOString(),messages:rows.map(x=>({address:String(x.address||'').slice(0,200),body:String(x.body||'').slice(0,4000),date:Number(x.date||0)}))};writeJson(smsFile,all);res.json({ok:true,count:rows.length})});
app.get('/api/photos',admin,(req,res)=>{const files=fs.readdirSync(uploadDir).filter(f=>fs.statSync(path.join(uploadDir,f)).isFile());res.json(files.map(f=>({name:f,url:'/uploads/'+encodeURIComponent(f)}))) });
app.delete('/api/photos/:name',admin,(req,res)=>{const p=path.join(uploadDir,path.basename(req.params.name));if(!fs.existsSync(p))return res.status(404).json({error:'Not found'});fs.unlinkSync(p);res.json({ok:true})});
app.get('/api/sms',admin,(req,res)=>res.json(Object.values(readJson(smsFile))));
app.get('/health',(req,res)=>res.json({ok:true}));
app.listen(PORT,()=>console.log(`Gallery Share server on ${PORT}`));
